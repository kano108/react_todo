import Student from './todo';
import './App.css'
function App() {
  return (
    <div className='outerbox'>
      <Student />
    </div>

  );
}

export default App